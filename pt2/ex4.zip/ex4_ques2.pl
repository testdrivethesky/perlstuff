#!/usr/local/bin/perl -w 
printf "%.2f\n", 34.6666666;
