#!/usr/local/bin/perl -w

print "What is the beginning Farenheit temperature?";
chomp($begtemp=<STDIN>);

$celsius=($begtemp - 32) / 1.8;

foreach $celsius (-273.16 .. 500){
if ($begtemp >= -459.69 && $celsius >= $begtemp ){printf "Initial Farenheit  %.2f  Celsius %.2f.\n", $begtemp, $celsius;}
else {print "Error found.\n";}
}

print "Please enter grades, separated by a space:";
chomp($grades=<STDIN>);
@input = split(' ',$grades);
$sum = 0;
foreach (@input){
	$sum += $_;
	$avg = ($sum / @input);		
}

print "Sum = $sum\n  Average = $avg\n";

OUTER: @suit=('spades', 'hearts', 'clubs', 'diamonds');
foreach  $suit(@suit) {
  INNER:  @types=("ace","2","3","4","5","6","7","8","9","10","jack","queen","king");
  foreach $types(@types) {
    $card="$types of $suit";
    print "$card\n";
    $cardcounter++;
    push(@cards,$card,);
    }

}
print "\n"x2;
print "$cardcounter cards are built in nested loops\n";
print "\n"x2;

RANDOM:
for ($counter=1;$counter<11;) {
$i = int(rand(@cards)) ;
push (@alreadyused,$cards[$i]);
$count=grep (/$cards[$i]/i,@alreadyused);

if ($count<2) {
  print "Random card is: $cards[$i]\n";
  $counter++;
  push (@iterations,$cards[$i]);
}
else {next RANDOM;}
}

print "\n"x2;
$number=@iterations;
print "$number random cards are selected";