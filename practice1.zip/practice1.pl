#!C:/Perl64/bin/perl.exe
print "Content-type: text/html \n\n"; #HTTP header
print "<html><head><title>My First PERL Script</title></head></html>";
print "<body><h1>Pilara Brunson</h1>\n"; 
print "<h2>732 762-4093</h2>\n";
print "<h2>testdrivethesky\@gmail.com<h2>\n";
print "<h2>To learn how to develop web-based applications using PERL.<h2>\n";
print "<h2>3 to 5 hours<h2>\n";